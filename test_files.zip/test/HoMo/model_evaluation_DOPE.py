from modeller.scripts import complete_pdb 
log.verbose() 
env = environ() 
env.libs.topology.read(file='$(LIB)/top_heav.lib') 
env.libs.parameters.read(file='$(LIB)/par.lib')
modelfile = open('/home/luck/knime-workspace/test_ghecom/test/HoMo/temp_list.log','r')


for lines in modelfile:
	model = lines.rstrip()
	mdl = complete_pdb(env, model)
	profile = model[:-4]+'.profile'
	s = selection(mdl)
	s.assess_dope(output='ENERGY_PROFILE NO_REPORT', file=profile,normalize_profile=True, smoothing_window=15)
