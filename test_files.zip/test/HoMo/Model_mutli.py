from modeller import * 
from modeller.automodel import * 
env = environ() 
a = automodel(env, alnfile= '/home/luck/knime-workspace/test_ghecom/test/HoMo/OR10A6_mult.ali', knowns = ('4iarA', '5cxvA', '3uonA'), sequence='OR10A6') 
a.starting_model = 1 
 
a.ending_model = 2 
a.make()
